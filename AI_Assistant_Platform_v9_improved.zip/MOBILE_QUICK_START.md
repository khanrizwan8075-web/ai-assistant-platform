# Mobile Quick Start

## GitHub Codespaces / browser IDE

1. Upload this project to a private GitHub repository.
2. Open **Code -> Codespaces -> Create codespace**.
3. In the terminal run:

```bash
chmod +x mobile_start.sh
./mobile_start.sh
```

If Docker Compose is present, this starts the stack with one command.

## Safety
- Do not commit real API keys, passwords, JWT secrets, or production credentials.
- Use `.env`/Codespaces secrets for private values.
- This package intentionally does not configure a production domain or TLS certificate.

## If the one-command start stops
Open `README.md` and `PRODUCTION_RUNBOOK.md` for the project's service-specific commands.
