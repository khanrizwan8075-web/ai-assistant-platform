# Production checklist

- [x] Authenticated chat and per-user conversations
- [x] Per-user document ownership and deletion
- [x] AI firewall and output secret redaction
- [x] Tool allowlist and bounded tool arguments
- [x] RAG chunking and retrieval
- [x] Docker + PostgreSQL + Caddy production stack
- [x] Health check, request IDs, metrics endpoint
- [x] Automated test suite
- [ ] Configure real secrets in deployment environment
- [ ] Configure DNS/domain and TLS
- [ ] Run a formal external security review (cannot be automated locally)
- [ ] Configure provider-specific integrations and live credentials (deployment-specific)
- [x] Frontend authentication sends JSON bodies matching backend schemas
- [x] Recursive firewall bounds nested tool arguments and rejects oversized structures
- [x] Additional deterministic low-risk utility tools registered through the same allowlist
- [x] Release validation includes frontend/backend contract checks
- [ ] Add a real embedding provider + pgvector if semantic RAG is required
- [ ] Add a container/gVisor worker for untrusted code execution if code execution is required
