# Extensible tools

Tools are registered with `@register_tool` in `backend/app/tools.py`.

A tool must have:
- a unique name
- a short description
- a JSON-schema parameter definition
- a safe handler
- low-risk behavior unless a future permission policy explicitly permits otherwise

The registry has no fixed maximum number of tools. Add new tools as modules and import them during application startup. Keep external/network/system tools behind explicit permissions, timeouts, auditing and sandboxing.
