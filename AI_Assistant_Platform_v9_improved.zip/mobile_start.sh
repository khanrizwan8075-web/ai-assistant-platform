#!/usr/bin/env bash
set -e

echo "=== AI Assistant Platform - Mobile Quick Start ==="
echo

if [ -f ".env.example" ] && [ ! -f ".env" ]; then
  cp .env.example .env
  echo "Created .env from .env.example"
fi

if [ -f "docker-compose.yml" ] || [ -f "compose.yml" ]; then
  COMPOSE_FILE="docker-compose.yml"
  [ -f "compose.yml" ] && COMPOSE_FILE="compose.yml"
  echo "Starting services with Docker Compose..."
  docker compose -f "$COMPOSE_FILE" up --build
  exit $?
fi

echo "No Docker Compose file detected."
echo "Use the commands documented in README.md / PRODUCTION_RUNBOOK.md."
