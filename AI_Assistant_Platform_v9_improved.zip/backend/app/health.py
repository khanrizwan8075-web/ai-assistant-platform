from sqlalchemy import text
from .db import engine

def database_ok():
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception:
        return False
