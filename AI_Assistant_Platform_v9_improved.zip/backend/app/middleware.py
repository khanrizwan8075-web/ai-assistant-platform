from time import perf_counter
from uuid import uuid4
from starlette.middleware.base import BaseHTTPMiddleware
from .metrics import record_request

class RequestMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        rid = request.headers.get('X-Request-ID') or str(uuid4())
        start = perf_counter()
        try:
            response = await call_next(request)
            record_request(request.url.path, response.status_code)
            response.headers['X-Request-ID'] = rid
            response.headers['X-Response-Time-ms'] = f'{(perf_counter()-start)*1000:.1f}'
            return response
        except Exception:
            record_request(request.url.path, 500)
            raise
