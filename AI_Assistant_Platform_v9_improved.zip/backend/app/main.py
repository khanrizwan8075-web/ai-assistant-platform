from pathlib import Path
from tempfile import NamedTemporaryFile
from fastapi import FastAPI, Depends, UploadFile, File, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi import status
from sqlalchemy.orm import Session
from sqlalchemy import select, delete
from pypdf import PdfReader
from docx import Document as DocxDocument
from .config import settings
from .db import Base, engine, get_db, SessionLocal
from .models import Conversation, Message, Document
from .audit import AuditLog
from .auth import User, Token, hash_password, verify_password, issue_token, require_user, revoke_token, normalize_email, purge_expired_tokens
from .rate_limit import limiter, auth_limiter
from .health import database_ok
from .schemas import AuthRequest, ChatRequest, ChatResponse, DocumentResponse
from .agents import run_agent
from .firewall import inspect_input, sanitize_output
from .tools import TOOLS, run_tool
from . import tools_extra  # noqa: F401 - registers additional safe tools
from .security import SecurityHeadersMiddleware
from .middleware import RequestMiddleware
from .metrics import snapshot

if settings.env.lower() != "production": Base.metadata.create_all(bind=engine)
app = FastAPI(title=settings.app_name, docs_url="/docs" if settings.docs_enabled else None, redoc_url="/redoc" if settings.docs_enabled else None)
app.add_middleware(RequestMiddleware); app.add_middleware(SecurityHeadersMiddleware)
origins = [x.strip() for x in settings.cors_origins.split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["GET","POST","DELETE"], allow_headers=["*"])

def owner_conversation(db, user_id, cid):
    item = db.get(Conversation, cid)
    if not item or item.user_id != user_id: raise HTTPException(404, "Conversation not found.")
    return item

def client_key(request: Request) -> str:
    return request.client.host if request.client else "unknown"

def audit(db, user_id, event, detail=""):
    db.add(AuditLog(user_id=user_id, event=event, detail=detail[:4000])); db.commit()

@app.get("/api/health")
def health():
    ok = database_ok(); return {"status":"ok" if ok else "degraded", "database":ok}

@app.get("/api/ready")
def ready():
    ok = database_ok() and (settings.env.lower() != "production" or bool(settings.llm_api_key and settings.llm_model))
    if not ok: raise HTTPException(503, "Service is not ready.")
    return {"ready": True}

@app.get("/api/metrics")
def metrics(request: Request):
    if not settings.admin_token or request.headers.get("X-Admin-Token") != settings.admin_token: raise HTTPException(403,"Unauthorized.")
    return snapshot()

@app.post("/api/auth/logout")
def logout(request: Request):
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        with SessionLocal() as db: revoke_token(db, auth[7:])
    return {"ok":True}

@app.post("/api/auth/register")
def register(req: AuthRequest, request: Request, db: Session = Depends(get_db)):
    auth_limiter.check("register:" + client_key(request)); email = normalize_email(str(req.email))
    if db.query(User).filter(User.email == email).first(): raise HTTPException(409,"Account already exists.")
    user = User(email=email, password_hash=hash_password(req.password)); db.add(user); db.commit(); db.refresh(user)
    audit(db, user.id, "auth.register")
    return {"id":user.id,"email":user.email}

@app.post("/api/auth/login")
def login(req: AuthRequest, request: Request, db: Session = Depends(get_db)):
    auth_limiter.check("login:" + client_key(request)); email = normalize_email(str(req.email))
    user = db.query(User).filter(User.email == email).first()
    if not user or not verify_password(req.password,user.password_hash): raise HTTPException(401,"Invalid email or password.")
    purge_expired_tokens(db); token = issue_token(db,user.id); audit(db,user.id,"auth.login")
    return {"access_token":token,"token_type":"bearer"}

@app.get("/api/me")
def me(user_id:int=Depends(require_user)): return {"user_id":user_id}

@app.get("/api/conversations")
def conversations(db:Session=Depends(get_db),user_id:int=Depends(require_user)):
    rows=db.scalars(select(Conversation).where(Conversation.user_id==user_id).order_by(Conversation.id.desc()).limit(100)).all()
    return [{"id":x.id,"title":x.title,"created_at":x.created_at} for x in rows]

@app.get("/api/conversations/{cid}")
def conversation(cid:int,db:Session=Depends(get_db),user_id:int=Depends(require_user)):
    item=owner_conversation(db,user_id,cid); rows=db.scalars(select(Message).where(Message.conversation_id==cid).order_by(Message.id)).all()
    return {"id":item.id,"title":item.title,"messages":[{"role":m.role,"content":m.content,"created_at":m.created_at} for m in rows]}

@app.delete("/api/conversations/{cid}")
def delete_conversation(cid:int,db:Session=Depends(get_db),user_id:int=Depends(require_user)):
    item=owner_conversation(db,user_id,cid); db.delete(item); db.commit(); audit(db,user_id,"conversation.delete",str(cid)); return {"ok":True}

@app.post("/api/chat",response_model=ChatResponse)
async def chat_endpoint(req:ChatRequest,db:Session=Depends(get_db),user_id:int=Depends(require_user)):
    limiter.check(str(user_id)); decision=inspect_input(req.message,settings.max_message_length)
    if not decision.allowed: return ChatResponse(conversation_id=req.conversation_id or 0,response=decision.reason,blocked=True)
    conversation=owner_conversation(db,user_id,req.conversation_id) if req.conversation_id else None
    if conversation is None:
        conversation=Conversation(user_id=user_id,title=req.message[:60]); db.add(conversation); db.commit(); db.refresh(conversation)
    history=[{"role":m.role,"content":m.content} for m in db.scalars(select(Message).where(Message.conversation_id==conversation.id).order_by(Message.id.desc()).limit(30)).all()][::-1]
    db.add(Message(conversation_id=conversation.id,role="user",content=req.message)); db.commit()
    try: answer=await run_agent(db,history,req.message,user_id=user_id)
    except PermissionError as exc: raise HTTPException(403,str(exc))
    except Exception as exc: raise HTTPException(502,"Assistant temporarily unavailable.") from exc
    answer=sanitize_output(answer); db.add(Message(conversation_id=conversation.id,role="assistant",content=answer)); db.commit()
    return ChatResponse(conversation_id=conversation.id,response=answer)

@app.post("/api/documents",response_model=DocumentResponse)
async def upload_document(file:UploadFile=File(...),db:Session=Depends(get_db),user_id:int=Depends(require_user)):
    name=Path(file.filename or "uploaded-file").name
    if len(name)>255: raise HTTPException(400,"Filename is too long.")
    raw=await file.read()
    if len(raw)>settings.max_upload_bytes: raise HTTPException(413,"Upload exceeds configured size limit.")
    suffix=Path(name).suffix.lower()
    allowed_types={".pdf",".docx",".txt",".md"}
    if suffix not in allowed_types: raise HTTPException(400,"Supported files: PDF, DOCX, TXT, MD")
    try:
        if suffix==".pdf":
            with NamedTemporaryFile(suffix=".pdf") as tmp:
                tmp.write(raw); tmp.flush(); content="\n".join((p.extract_text() or "") for p in PdfReader(tmp.name).pages)
        elif suffix==".docx":
            with NamedTemporaryFile(suffix=".docx") as tmp:
                tmp.write(raw); tmp.flush(); content="\n".join(p.text for p in DocxDocument(tmp.name).paragraphs)
        elif suffix in {".txt",".md"}: content=raw.decode("utf-8",errors="replace")
    except HTTPException: raise
    except Exception as exc: raise HTTPException(400,"Could not read the uploaded file.") from exc
    content=content.strip()
    if not content: raise HTTPException(400,"File contains no readable text.")
    if len(content)>settings.max_extracted_chars: raise HTTPException(413,"Extracted text is too large.")
    item=Document(user_id=user_id,name=name,content=content); db.add(item); db.commit(); db.refresh(item); audit(db,user_id,"document.upload",name)
    return DocumentResponse(id=item.id,name=item.name)

@app.get("/api/documents")
def documents(db:Session=Depends(get_db),user_id:int=Depends(require_user)):
    return [{"id":d.id,"name":d.name,"created_at":d.created_at} for d in db.scalars(select(Document).where(Document.user_id==user_id).order_by(Document.id.desc())).all()]

@app.delete("/api/documents/{did}")
def delete_document(did:int,db:Session=Depends(get_db),user_id:int=Depends(require_user)):
    d=db.get(Document,did)
    if not d or d.user_id!=user_id: raise HTTPException(404,"Document not found.")
    db.delete(d); db.commit(); audit(db,user_id,"document.delete",str(did)); return {"ok":True}

@app.get("/api/tools")
def list_tools(user_id:int=Depends(require_user)):
    return [{"name":t.name,"description":t.description,"risk":t.risk,"parameters":t.parameters} for t in TOOLS.values()]

@app.post("/api/tools/{name}")
def execute_tool(name:str,args:dict,user_id:int=Depends(require_user),db:Session=Depends(get_db)):
    decision=inspect_input(name,100)
    if not decision.allowed: raise HTTPException(400,"Invalid tool name.")
    try: result=run_tool(name,args); audit(db,user_id,"tool.execute",name); return {"tool":name,"result":result}
    except PermissionError as exc: raise HTTPException(403,str(exc))
    except Exception as exc:
        # Do not expose internal tool errors to clients.
        raise HTTPException(400,"Tool execution failed.") from exc

@app.get("/")
def home(): return FileResponse("frontend/index.html")
