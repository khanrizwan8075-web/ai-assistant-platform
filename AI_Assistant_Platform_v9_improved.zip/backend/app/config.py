from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "AI Assistant Platform"
    env: str = "development"
    database_url: str = "sqlite:///./data/assistant.db"
    llm_base_url: str = "https://api.openai.com/v1"
    llm_api_key: str = ""
    llm_model: str = ""
    llm_timeout_seconds: float = Field(default=60, gt=0, le=300)
    cors_origins: str = "http://localhost:8000"
    max_message_length: int = Field(default=12000, ge=100, le=100000)
    rate_limit_per_minute: int = Field(default=30, ge=1, le=10000)
    auth_rate_limit_per_minute: int = Field(default=10, ge=1, le=100)
    max_upload_bytes: int = Field(default=10_000_000, ge=1024, le=100_000_000)
    max_extracted_chars: int = Field(default=300_000, ge=1000, le=2_000_000)
    admin_token: str = ""
    docs_enabled: bool = True
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
