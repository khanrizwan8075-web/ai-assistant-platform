import httpx
from .config import settings
class LLMError(RuntimeError): pass

async def chat(messages: list[dict], tools: list[dict] | None = None):
    if not settings.llm_api_key or not settings.llm_model:
        raise LLMError("LLM_API_KEY and LLM_MODEL must be configured.")
    url=settings.llm_base_url.rstrip("/")+"/chat/completions"
    payload={"model":settings.llm_model,"messages":messages,"temperature":0.2}
    if tools: payload.update({"tools":tools,"tool_choice":"auto"})
    try:
        async with httpx.AsyncClient(timeout=settings.llm_timeout_seconds) as client:
            response=await client.post(url,headers={"Authorization":f"Bearer {settings.llm_api_key}"},json=payload)
            response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        raise LLMError(f"LLM provider returned HTTP {exc.response.status_code}.") from exc
    except httpx.HTTPError as exc:
        raise LLMError("Could not reach the LLM provider.") from exc
    try:
        message=response.json()["choices"][0]["message"]
    except (ValueError,KeyError,IndexError,TypeError) as exc:
        raise LLMError("Unexpected LLM response format.") from exc
    if message.get("tool_calls"): return {"message":message}
    return message.get("content","") or ""
