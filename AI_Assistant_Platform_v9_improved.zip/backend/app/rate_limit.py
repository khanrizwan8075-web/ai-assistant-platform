import time
from collections import defaultdict, deque
from threading import Lock
from fastapi import HTTPException

class RateLimiter:
    def __init__(self, limit=30, window=60):
        self.limit, self.window = limit, window
        self.events = defaultdict(deque)
        self.lock = Lock()

    def check(self, key: str):
        now = time.time()
        with self.lock:
            q = self.events[key]
            while q and q[0] <= now - self.window:
                q.popleft()
            if len(q) >= self.limit:
                raise HTTPException(429, "Rate limit exceeded. Try again later.")
            q.append(now)

    def cleanup(self):
        now = time.time()
        with self.lock:
            for key in list(self.events):
                q = self.events[key]
                while q and q[0] <= now - self.window:
                    q.popleft()
                if not q:
                    del self.events[key]

from .config import settings
limiter = RateLimiter(settings.rate_limit_per_minute)
auth_limiter = RateLimiter(settings.auth_rate_limit_per_minute)
