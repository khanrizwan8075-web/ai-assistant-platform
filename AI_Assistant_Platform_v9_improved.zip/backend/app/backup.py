"""Database backup helper. Run from the project root.
SQLite: python -m backend.app.backup --output backups/assistant.db
PostgreSQL: use pg_dump with DATABASE_URL in your deployment backup job.
"""
import argparse, os, shutil
from pathlib import Path
from urllib.parse import urlparse
from .config import settings

def sqlite_backup(output: str):
    src = Path(settings.database_url.removeprefix('sqlite:///'))
    dst = Path(output); dst.parent.mkdir(parents=True, exist_ok=True)
    if not src.exists(): raise FileNotFoundError(src)
    shutil.copy2(src, dst)
    return str(dst)

if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('--output', default='backups/assistant.db'); a=p.parse_args()
    if not settings.database_url.startswith('sqlite:///'):
        raise SystemExit('For PostgreSQL, schedule pg_dump using the DATABASE_URL from your secret manager.')
    print(sqlite_backup(a.output))
