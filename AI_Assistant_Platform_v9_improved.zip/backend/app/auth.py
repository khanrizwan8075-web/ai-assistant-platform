from datetime import datetime, timedelta, timezone
import hashlib, hmac, secrets, re
from fastapi import Header, HTTPException
from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base, SessionLocal

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(256))
    created_at: Mapped[datetime] = mapped_column(default=lambda: datetime.now(timezone.utc))

class Token(Base):
    __tablename__ = "tokens"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    expires_at: Mapped[datetime] = mapped_column()

def normalize_email(email: str) -> str:
    email = email.strip().lower()
    if len(email) > 320 or not EMAIL_RE.fullmatch(email):
        raise HTTPException(400, "Invalid email address.")
    return email

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return (salt + digest).hex()

def verify_password(password: str, stored: str) -> bool:
    try: raw = bytes.fromhex(stored)
    except ValueError: return False
    if len(raw) != 80: return False
    salt, expected = raw[:16], raw[16:]
    try: actual = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    except (ValueError, OverflowError): return False
    return hmac.compare_digest(actual, expected)

def issue_token(db, user_id: int, hours=24) -> str:
    raw = secrets.token_urlsafe(32)
    token = Token(user_id=user_id, token_hash=hashlib.sha256(raw.encode()).hexdigest(),
                  expires_at=datetime.now(timezone.utc) + timedelta(hours=hours))
    db.add(token); db.commit(); return raw

def require_user(authorization: str | None = Header(default=None)) -> int:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Authentication required.")
    raw = authorization[7:].strip()
    if not raw or len(raw) > 512: raise HTTPException(401, "Invalid or expired token.")
    digest = hashlib.sha256(raw.encode()).hexdigest()
    with SessionLocal() as db:
        token = db.query(Token).filter(Token.token_hash == digest).first()
        if not token or token.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
            raise HTTPException(401, "Invalid or expired token.")
        return token.user_id

def revoke_token(db, raw: str) -> None:
    digest = hashlib.sha256(raw.encode()).hexdigest()
    token = db.query(Token).filter(Token.token_hash == digest).first()
    if token: db.delete(token); db.commit()

def purge_expired_tokens(db) -> int:
    from sqlalchemy import delete
    cutoff = datetime.now(timezone.utc)
    result = db.execute(delete(Token).where(Token.expires_at < cutoff)); db.commit()
    return result.rowcount or 0
