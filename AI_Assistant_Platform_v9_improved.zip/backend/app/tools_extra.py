"""Additional deterministic, low-risk tools kept separate from privileged adapters."""
from datetime import datetime, timezone
from .tools import register_tool

@register_tool("text_upper", "Convert text to uppercase.", {"type":"object","properties":{"text":{"type":"string"}},"required":["text"]})
def text_upper(text: str):
    return {"text": text.upper()}

@register_tool("text_lower", "Convert text to lowercase.", {"type":"object","properties":{"text":{"type":"string"}},"required":["text"]})
def text_lower(text: str):
    return {"text": text.lower()}

@register_tool("text_reverse", "Reverse a text string.", {"type":"object","properties":{"text":{"type":"string"}},"required":["text"]})
def text_reverse(text: str):
    return {"text": text[::-1]}

@register_tool("iso_date", "Return the current UTC date in ISO format.", {"type":"object","properties":{}})
def iso_date():
    return {"date": datetime.now(timezone.utc).date().isoformat()}
