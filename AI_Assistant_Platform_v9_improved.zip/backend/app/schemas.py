from pydantic import BaseModel, Field, EmailStr

class AuthRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=256)

class ChatRequest(BaseModel):
    conversation_id: int | None = Field(default=None, ge=1)
    message: str = Field(min_length=1, max_length=12000)

class ChatResponse(BaseModel):
    conversation_id: int
    response: str
    blocked: bool = False

class DocumentResponse(BaseModel):
    id: int
    name: str
