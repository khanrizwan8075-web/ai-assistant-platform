from collections import Counter
from threading import Lock
from time import time

_lock = Lock()
_started = time()
_requests = Counter()
_errors = Counter()


def record_request(path: str, status: int):
    with _lock:
        _requests[(path, str(status))] += 1
        if status >= 500:
            _errors[path] += 1


def snapshot():
    with _lock:
        return {
            'uptime_seconds': round(time() - _started, 2),
            'requests': {f'{p}|{s}': n for (p, s), n in _requests.items()},
            'server_errors': dict(_errors),
        }
