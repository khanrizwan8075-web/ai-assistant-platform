import re
from collections import Counter
from sqlalchemy import select
from sqlalchemy.orm import Session
from .models import Document

STOP = {"the","and","for","with","that","this","from","are","was","you","your","have","has","not","but"}

def normalize(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9]{2,}", text.lower()) if t not in STOP]

def score(query: str, document: str) -> float:
    q = Counter(normalize(query)); d = Counter(normalize(document))
    if not q: return 0.0
    overlap = sum(min(q[k], d[k]) for k in q)
    return overlap / sum(q.values())

def chunks(text: str, size: int = 1800, overlap: int = 250) -> list[str]:
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if len(text) <= size: return [text]
    out=[]; start=0
    while start < len(text):
        end=min(len(text), start+size)
        if end < len(text):
            cut=max(text.rfind("\n", start, end), text.rfind(" ", start, end))
            if cut > start + size//2: end=cut
        out.append(text[start:end].strip())
        if end >= len(text): break
        start=max(start+1, end-overlap)
    return [x for x in out if x]

def retrieve(db: Session, query: str, limit: int = 5, user_id: int | None = None) -> list[str]:
    stmt=select(Document)
    if user_id is not None: stmt=stmt.where(Document.user_id == user_id)
    docs=db.scalars(stmt).all()
    ranked=[]
    for doc in docs:
        for chunk in chunks(doc.content):
            s=score(query, chunk)
            if s>0: ranked.append((s, chunk))
    ranked.sort(key=lambda x:x[0], reverse=True)
    return [c[:5000] for _,c in ranked[:limit]]
