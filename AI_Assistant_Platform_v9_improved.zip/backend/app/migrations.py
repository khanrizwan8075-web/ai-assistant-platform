# Migration entry point.
# For production, install Alembic and replace create_all with versioned migrations.
# Keeping schema changes versioned is recommended for zero-downtime deployments.
