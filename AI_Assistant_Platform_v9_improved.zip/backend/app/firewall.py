import json, re
from dataclasses import dataclass

@dataclass
class FirewallDecision:
    allowed: bool
    reason: str = ""

# Conservative, explainable baseline patterns. Semantic/LLM-based inspection can be
# layered on top, but should never be the only security boundary.
BLOCKED_PATTERNS = [
    r"(?:\b|_)system\s*prompt(?:\b|_)",
    r"ignore\s+(all\s+)?previous\s+instructions",
    r"reveal\s+(your|the)\s+system\s+prompt",
    r"show\s+me\s+your\s+hidden\s+instructions",
    r"developer\s+message",
    r"system\s+prompt",
    r"(?:jailbreak|prompt\s*injection)",
]
SECRET_PATTERNS = [
    r"sk-[A-Za-z0-9_-]{20,}",
    r"api[_-]?key\s*[:=]\s*\S+",
    r"password\s*[:=]\s*\S+",
    r"bearer\s+[A-Za-z0-9._~+/=-]{20,}",
]
MAX_TOOL_DEPTH = 6
MAX_TOOL_NODES = 200


def inspect_input(text: str, max_length: int = 12000) -> FirewallDecision:
    if not isinstance(text, str) or len(text) > max_length:
        return FirewallDecision(False, "Message exceeds the configured length limit.")
    lowered = text.casefold()
    for pattern in BLOCKED_PATTERNS:
        if re.search(pattern, lowered):
            return FirewallDecision(False, "Request blocked by AI firewall.")
    return FirewallDecision(True)


def _validate_value(value, depth=0, state=None):
    if state is None:
        state = {"nodes": 0}
    state["nodes"] += 1
    if state["nodes"] > MAX_TOOL_NODES:
        return False
    if depth > MAX_TOOL_DEPTH:
        return False
    if isinstance(value, str):
        if len(value) > 5000:
            return False
        return inspect_input(value, 5000).allowed
    if isinstance(value, dict):
        if len(value) > 50:
            return False
        return all(_validate_value(k, depth + 1, state) and _validate_value(v, depth + 1, state) for k, v in value.items())
    if isinstance(value, list):
        if len(value) > 50:
            return False
        return all(_validate_value(v, depth + 1, state) for v in value)
    return isinstance(value, (int, float, bool)) or value is None


def inspect_tool_call(tool_name: str, args: dict) -> FirewallDecision:
    from .tools import TOOLS
    if not isinstance(tool_name, str) or tool_name not in TOOLS:
        return FirewallDecision(False, "Tool is not registered.")
    if not isinstance(args, dict):
        return FirewallDecision(False, "Tool arguments must be an object.")
    try:
        encoded = json.dumps(args, ensure_ascii=False)
    except (TypeError, ValueError):
        return FirewallDecision(False, "Tool arguments are invalid.")
    if len(encoded) > 5000 or not _validate_value(args):
        return FirewallDecision(False, "Tool arguments are invalid or too large.")
    return FirewallDecision(True)


def sanitize_output(text: str) -> str:
    if not isinstance(text, str):
        return ""
    result = text.strip()
    for pattern in SECRET_PATTERNS:
        result = re.sub(pattern, "[REDACTED]", result, flags=re.I)
    return result[:50000]
