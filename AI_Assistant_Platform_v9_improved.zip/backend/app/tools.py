"""Extensible, policy-gated tool registry.

New safe tools can be added with @register_tool. No shell/process/network/browser
execution is exposed by default; those integrations should be implemented behind
explicit, audited adapters and permission policies.
"""
import ast
import base64
import hashlib
import json
import math
import operator as op
import re
import uuid
from datetime import datetime, timezone
from dataclasses import dataclass
from typing import Any, Callable
from .firewall import inspect_tool_call

OPS = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv, ast.Pow: op.pow, ast.Mod: op.mod}

@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    parameters: dict
    handler: Callable[..., Any]
    risk: str = "low"

TOOLS: dict[str, Tool] = {}

def register_tool(name: str, description: str, parameters: dict, risk: str = "low"):
    def decorator(fn):
        TOOLS[name] = Tool(name, description, parameters, fn, risk)
        return fn
    return decorator

def safe_calculator(expression: str) -> float:
    tree = ast.parse(expression, mode="eval")
    def visit(node):
        if isinstance(node, ast.Expression): return visit(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool): return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in OPS:
            left, right = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 10: raise ValueError("Exponent too large.")
            if isinstance(node.op, ast.Div) and right == 0: raise ValueError("Division by zero.")
            return OPS[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            value = visit(node.operand); return value if isinstance(node.op, ast.UAdd) else -value
        raise ValueError("Unsupported expression.")
    result = visit(tree)
    if not math.isfinite(result): raise ValueError("Result is not finite.")
    return result

@register_tool("calculator", "Safely evaluate basic arithmetic.", {"type":"object","properties":{"expression":{"type":"string"}},"required":["expression"]})
def calculator(expression: str): return {"result": safe_calculator(expression)}

@register_tool("text_stats", "Count characters, words and lines.", {"type":"object","properties":{"text":{"type":"string"}},"required":["text"]})
def text_stats(text: str): return {"characters":len(text),"words":len(re.findall(r"\S+",text)),"lines":len(text.splitlines()) or 1}

@register_tool("json_format", "Parse and pretty-print JSON.", {"type":"object","properties":{"text":{"type":"string"}},"required":["text"]})
def json_format(text: str): return {"json": json.dumps(json.loads(text), indent=2, ensure_ascii=False)}

@register_tool("regex_find", "Find regex matches in text.", {"type":"object","properties":{"pattern":{"type":"string"},"text":{"type":"string"}},"required":["pattern","text"]})
def regex_find(pattern: str, text: str): return {"matches": re.findall(pattern, text)[:200]}

@register_tool("hash_sha256", "Create a SHA-256 hash of text.", {"type":"object","properties":{"text":{"type":"string"}},"required":["text"]})
def hash_sha256(text: str): return {"sha256": hashlib.sha256(text.encode()).hexdigest()}

@register_tool("base64_encode", "Base64-encode UTF-8 text.", {"type":"object","properties":{"text":{"type":"string"}},"required":["text"]})
def base64_encode(text: str): return {"base64": base64.b64encode(text.encode()).decode()}

@register_tool("base64_decode", "Decode Base64 UTF-8 text.", {"type":"object","properties":{"text":{"type":"string"}},"required":["text"]})
def base64_decode(text: str): return {"text": base64.b64decode(text, validate=True).decode("utf-8")}

@register_tool("uuid", "Generate a UUID4.", {"type":"object","properties":{}})
def uuid_tool(): return {"uuid": str(uuid.uuid4())}

@register_tool("utc_time", "Return the current UTC time.", {"type":"object","properties":{}})
def utc_time(): return {"utc": datetime.now(timezone.utc).isoformat()}

@register_tool("memory_search", "Search uploaded knowledge for matching text.", {"type":"object","properties":{"query":{"type":"string"}},"required":["query"]})
def memory_search(query: str):
    # DB-backed execution is handled by the agent; this registry entry documents the contract.
    return {"query": query}

def tool_schemas() -> list[dict]:
    return [{"type":"function","function":{"name":t.name,"description":t.description,"parameters":t.parameters}} for t in TOOLS.values()]

def run_tool(name: str, args: dict):
    if not isinstance(name, str) or not name or len(name) > 100:
        raise PermissionError("Invalid tool name.")
    if not isinstance(args, dict):
        raise PermissionError("Tool arguments must be an object.")
    decision = inspect_tool_call(name, args)
    if not decision.allowed: raise PermissionError(decision.reason)
    tool = TOOLS.get(name)
    if not tool: raise ValueError("Unknown tool.")
    if tool.risk != "low": raise PermissionError("Tool requires an explicit permission policy.")
    return tool.handler(**args)
