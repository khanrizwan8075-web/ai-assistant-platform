from pathlib import Path

HTML = Path(__file__).resolve().parents[2] / "frontend" / "index.html"

def test_frontend_auth_uses_json_api_requests():
    text = HTML.read_text()
    assert "/api/auth/register?email=" not in text
    assert "/api/auth/login?email=" not in text
    assert "JSON.stringify({email:$('email').value.trim(),password:$('password').value})" in text
