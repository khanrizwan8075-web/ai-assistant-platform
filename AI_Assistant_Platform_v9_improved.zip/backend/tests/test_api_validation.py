from fastapi import HTTPException
from backend.app.main import owner_conversation
from backend.app.models import Conversation

def test_conversation_owner_check_rejects_missing_or_foreign():
    class DB:
        def __init__(self, item): self.item = item
        def get(self, model, cid): return self.item
    try:
        owner_conversation(DB(None), 1, 1)
        assert False
    except HTTPException as exc:
        assert exc.status_code == 404
    try:
        owner_conversation(DB(Conversation(id=1, user_id=2)), 1, 1)
        assert False
    except HTTPException as exc:
        assert exc.status_code == 404
