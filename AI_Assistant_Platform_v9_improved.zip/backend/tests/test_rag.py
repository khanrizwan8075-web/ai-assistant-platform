from backend.app.rag import score,chunks

def test_rag_score():
    assert score("python database","Python is used with databases")>0
    assert score("python","gardening tools")==0

def test_chunks():
    parts=chunks("word "*1000,size=500,overlap=50)
    assert len(parts)>1 and all(parts)
