from backend.app.auth import hash_password, verify_password

def test_password_hashing():
    stored = hash_password("correct-password")
    assert verify_password("correct-password", stored)
    assert not verify_password("wrong-password", stored)
