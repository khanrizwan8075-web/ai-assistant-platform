import os
os.environ["DATABASE_URL"] = "sqlite:///./data/test_hardening.db"
from fastapi.testclient import TestClient
from backend.app.main import app

client=TestClient(app)

def test_auth_and_ownership():
    email="hardening@example.com"; pw="StrongPass123!"
    r=client.post('/api/auth/register',json={'email':email,'password':pw}); assert r.status_code in (200,409)
    r=client.post('/api/auth/login',json={'email':email,'password':pw}); assert r.status_code==200
    token=r.json()['access_token']; h={'Authorization':f'Bearer {token}'}
    assert client.get('/api/me',headers=h).status_code==200
    assert client.get('/api/conversations',headers=h).status_code==200

def test_invalid_email_rejected():
    r=client.post('/api/auth/register',json={'email':'not-an-email','password':'StrongPass123!'})
    assert r.status_code in (400,422)

def test_tools_require_auth():
    assert client.get('/api/tools').status_code==401

def test_health_and_ready():
    assert client.get('/api/health').status_code==200
    assert client.get('/api/ready').status_code in (200,503)
