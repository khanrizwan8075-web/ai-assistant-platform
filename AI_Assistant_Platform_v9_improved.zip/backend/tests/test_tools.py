from backend.app.tools import safe_calculator

def test_calculator():
    assert safe_calculator("2 + 3 * 4") == 14

def test_power():
    assert safe_calculator("2 ** 3") == 8

def test_registry_tools():
    from backend.app.tools import TOOLS, run_tool
    assert "calculator" in TOOLS
    assert run_tool("text_stats", {"text":"hello world"})["words"] == 2
