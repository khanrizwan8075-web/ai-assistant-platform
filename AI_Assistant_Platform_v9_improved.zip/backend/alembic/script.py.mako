"""${message}"""
revision = ${repr(up_revision)}
down_revision = ${repr(down_revision)}
from alembic import op
import sqlalchemy as sa
${upgrades if upgrades else ""}
${downgrades if downgrades else ""}
