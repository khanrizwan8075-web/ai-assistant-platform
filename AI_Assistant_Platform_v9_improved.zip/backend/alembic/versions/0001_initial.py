from alembic import op
import sqlalchemy as sa

revision='0001_initial'; down_revision=None; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('users', sa.Column('id',sa.Integer(),primary_key=True),sa.Column('email',sa.String(320),nullable=False),sa.Column('password_hash',sa.String(256),nullable=False),sa.Column('created_at',sa.DateTime(timezone=True),nullable=False))
    op.create_index('ix_users_email','users',['email'],unique=True)
    op.create_table('tokens', sa.Column('id',sa.Integer(),primary_key=True),sa.Column('user_id',sa.Integer(),nullable=False),sa.Column('token_hash',sa.String(64),nullable=False),sa.Column('expires_at',sa.DateTime(),nullable=False))
    op.create_index('ix_tokens_user_id','tokens',['user_id']); op.create_index('ix_tokens_token_hash','tokens',['token_hash'],unique=True)
    op.create_table('conversations',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('user_id',sa.Integer()),sa.Column('title',sa.String(200),nullable=False),sa.Column('created_at',sa.DateTime(timezone=True),nullable=False))
    op.create_index('ix_conversations_user_id','conversations',['user_id'])
    op.create_table('messages',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('conversation_id',sa.Integer(),sa.ForeignKey('conversations.id',ondelete='CASCADE'),nullable=False),sa.Column('role',sa.String(30),nullable=False),sa.Column('content',sa.Text(),nullable=False),sa.Column('created_at',sa.DateTime(timezone=True),nullable=False))
    op.create_index('ix_messages_conversation_id','messages',['conversation_id'])
    op.create_table('documents',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('user_id',sa.Integer()),sa.Column('name',sa.String(255),nullable=False),sa.Column('content',sa.Text(),nullable=False),sa.Column('created_at',sa.DateTime(timezone=True),nullable=False))
    op.create_index('ix_documents_user_id','documents',['user_id'])
    op.create_table('audit_logs',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('user_id',sa.Integer(),nullable=True),sa.Column('event',sa.String(100),nullable=False),sa.Column('detail',sa.Text(),nullable=False),sa.Column('created_at',sa.DateTime(timezone=True),nullable=False))
    op.create_index('ix_audit_logs_user_id','audit_logs',['user_id'])

def downgrade():
    op.drop_table('audit_logs'); op.drop_table('documents'); op.drop_table('messages'); op.drop_table('conversations'); op.drop_table('tokens'); op.drop_table('users')
