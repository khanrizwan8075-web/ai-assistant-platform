# Database migrations

This directory contains the versioned Alembic schema. Run `alembic -c backend/alembic.ini upgrade head` before production startup. New schema changes must be added as new revisions rather than relying on `create_all`.
