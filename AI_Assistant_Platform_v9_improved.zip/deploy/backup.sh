#!/usr/bin/env sh
set -eu
mkdir -p backups
# Run this script from the host where docker compose is running.
docker compose -f docker-compose.prod.yml exec -T db pg_dump -U "${POSTGRES_USER:-assistant}" -d "${POSTGRES_DB:-assistant}" | gzip > "backups/assistant-$(date +%Y%m%d-%H%M%S).sql.gz"
