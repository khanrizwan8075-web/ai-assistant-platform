@echo off
echo === AI Assistant Platform - Quick Start ===
if exist .env.example if not exist .env copy .env.example .env
if exist docker-compose.yml (
  docker compose -f docker-compose.yml up --build
  goto :eof
)
if exist compose.yml (
  docker compose -f compose.yml up --build
  goto :eof
)
echo No Docker Compose file detected. See README.md / PRODUCTION_RUNBOOK.md.
