# AI Assistant Platform — Production-ready foundation

A full-stack Python/FastAPI AI assistant with authenticated conversations, private document RAG/memory, an AI firewall, policy-gated tools, PostgreSQL support, Docker deployment, health/metrics, and a responsive web UI.

## Included
- FastAPI backend + responsive browser frontend
- Per-user authentication and conversation isolation
- PDF/DOCX/TXT/MD knowledge uploads with chunked retrieval
- Firewall for prompt-injection patterns, bounded inputs and secret redaction
- Extensible safe tool registry: calculator, text stats, JSON, regex, SHA-256, Base64, UUID, UTC time, memory search
- Rate limiting, security headers, request IDs and metrics
- Alembic migrations
- Local SQLite and production PostgreSQL compose stack
- Caddy HTTPS reverse proxy configuration
- Automated tests

## Local run
1. `cp .env.example .env`
2. Set `LLM_API_KEY`, `LLM_BASE_URL`, and `LLM_MODEL`.
3. `pip install -r backend/requirements.txt`
4. `alembic -c backend/alembic.ini upgrade head`
5. `PYTHONPATH=. uvicorn backend.app.main:app --reload`
6. Open `http://localhost:8000`.

## Docker
`cp .env.example .env && docker compose up --build`

For production, configure the secrets/domain and run `docker compose -f docker-compose.prod.yml up -d --build`.

## Tests
`PYTHONPATH=. python -m pytest -q backend/tests`

## Important
This is a strong production-oriented foundation, not a security certification. Public deployment still requires real secrets, HTTPS, backups, monitoring, dependency updates and a professional security review.
