# Production runbook

1. Copy `.env.example` to `.env` and set strong random `POSTGRES_PASSWORD`, `ADMIN_TOKEN`, `LLM_API_KEY`, `LLM_MODEL`, `CORS_ORIGINS`, and `DOMAIN`.
2. Never commit `.env` or secrets.
3. Start with `docker compose -f docker-compose.prod.yml up -d --build`.
4. Run migrations inside the app container: `docker compose -f docker-compose.prod.yml exec assistant alembic upgrade head`.
5. Confirm `https://YOUR_DOMAIN/api/health` returns database=true.
6. Schedule `deploy/backup.sh` with cron and periodically test restores.
7. Metrics are available only with `X-Admin-Token` matching `ADMIN_TOKEN`.
8. Caddy obtains and renews HTTPS certificates automatically when DNS points at the server and ports 80/443 are reachable.
9. For Android/iOS, use the same HTTPS API from a native/PWA client; the backend is device-independent.
