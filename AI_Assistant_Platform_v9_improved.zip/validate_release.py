from pathlib import Path
import subprocess, sys

ROOT = Path(__file__).resolve().parent
required = [
    "backend/app/main.py", "backend/app/firewall.py", "backend/app/tools.py",
    "backend/app/agents.py", "backend/app/auth.py", "backend/app/rag.py",
    "docker-compose.yml", "docker-compose.prod.yml", "Dockerfile",
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    print("MISSING:", *missing, sep="\n- ")
    raise SystemExit(1)

py = [str(p) for p in (ROOT / "backend").rglob("*.py")]
result = subprocess.run([sys.executable, "-m", "py_compile", *py], cwd=ROOT)
if result.returncode:
    raise SystemExit(result.returncode)
result = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=ROOT)
raise SystemExit(result.returncode)
