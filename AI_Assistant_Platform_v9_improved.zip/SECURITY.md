# Security controls

- Passwords use memory-hard `scrypt` hashing.
- Bearer tokens are stored hashed and expire; logout revokes the presented token.
- Per-user rate limiting is enabled from configuration.
- Input firewall blocks common prompt-exfiltration patterns and enforces length limits.
- Tool calls are registry-gated, argument-limited, and low-risk-only by default.
- Tool outputs are sanitized for common API-key/password patterns.
- Conversations and uploaded documents are scoped to the authenticated user.
- Upload size is configurable and file types are restricted.
- Security headers include CSP, frame denial, MIME sniffing protection and HSTS in production.
- Admin metrics require a separate secret header.
- Production uses PostgreSQL and Caddy HTTPS in the supplied compose file.

## Important
Do not add shell execution, arbitrary code execution, unrestricted browser automation, or unrestricted network fetch tools to the default registry. Such integrations require a separate permission policy, sandboxing, timeouts, and auditing.
